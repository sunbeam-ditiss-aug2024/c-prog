// Loops :

/*
Entry Controlled Loops : The exit condition is checked before entering the loop
1) While Loop
2) For loop

Exit Controlled Loop : The condition is checked at the exit of the loop
1) do - while :

*/

/*
Every loop has 3 parts
1) loop variable initialization
2) condition check
3) loop variable modification
*/

#include<stdio.h>
int main()
{
   // int i = 1; // loop variable initialization
/*
    while( i <= 10 ) // while(0)
    {
        printf("%d\n",i); // 1 2 3..... 10
        i++; // i = i + 1; ==> loop variable modification
    }
*/

 
//Program to print the table of a given number.

    int num;
    printf("Enter the number to print its table :");
    scanf("%d",&num);

    int i = 1;

    while( i <= 10)
    {
        printf("%d * %d = %d\n",num,i,num * i);
        // 5 * 1 = 5
        // 5 * 2 = 10
        i++;
    }
    return 0;
}

