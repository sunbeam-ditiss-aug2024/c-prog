// conditional statements : if-else
// check which number is greater

#include<stdio.h>

int main()
{
    int num1 = 65, num2 = 45;

    if(num1 <= num2) // if(0)
    {
        printf("Num2 is Greater !\n");
    }
    else
    {
        printf("Num1 is Greater !\n");
    }

    return 0;
}