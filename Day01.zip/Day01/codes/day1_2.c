// Data types

#include<stdio.h>

void main()
{
    int num = 50; // initialization
    char ch = 'A';
    float f_var = 1.2;
    double d_num = 3.5;

    int num2; // garbage value

    printf("value of num = %d\n",num);
    // value of num = 50

    printf("value of ch = %c\n",ch);
    // value of ch = A

    printf("value of f_var = %.2f\n",f_var);

    printf("Value of d_num = %.3lf\n",d_num);

    printf("value of num2 = %d\n",num2);

    
}