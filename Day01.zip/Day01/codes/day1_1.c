// Hello world

#include<stdio.h>

int main()
{
    printf("Hello Students ! Welcome to SUNBEAM !");
    return 0; // exit status : success
}
// return_type  function_name ()

/*

void main()
{
    printf("Hello !");
}

*/