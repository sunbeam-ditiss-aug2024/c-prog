// Operators : Arithmetic
// + - * / %
#include<stdio.h>

void main()
{
    int num1 = 50, num2 = 20;

    printf("Addition = %d\n",num1 + num2);

    int result = num1 - num2;

    printf("Subtraction = %d\n",result);
    printf("Multiplication = %d\n",num1 * num2);
    printf("Division = %d\n",num1 / num2); // Quotient
    printf("Modulus = %d\n",num1 % num2); // remainder

}