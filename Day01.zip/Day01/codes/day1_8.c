// if-else if
/* calculator:
Accept 2 numbers from the user and perform the operation
as per the user requirement.
*/

#include<stdio.h>

int main()
{
    char op;

    printf("Enter the Operator (+,-,*,/) :");
    scanf("%c",&op);

    int num1,num2;
    printf("Enter the values for num1 and num2 :");
    scanf("%d%d",&num1,&num2); // 35 20

    if(op == '+')
        printf("%d + %d = %d\n",num1,num2,num1 + num2);
    else if(op == '-')
        printf("%d - %d = %d\n",num1,num2,num1 - num2);
    else if(op == '*')
        printf("%d * %d = %d\n",num1,num2,num1 * num2);
    else if(op == '/')
    {
        if(num2 != 0)
            printf("%d / %d = %d\n",num1,num2,num1 / num2);
        else
            printf("Error ! Division by 0 is not allowed !\n");
    }
    else
    {
        printf("Invalid Operator !");
    }
}
