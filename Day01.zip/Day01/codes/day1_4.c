// OPerators : Relational ops 
// <  <=  >  >=  ==  !=
// the output is either 0 for false or 1 for true

#include<stdio.h>

void main()
{
    int num1,num2;

    printf("Enter the values for num1 and num2 :");
    scanf("%d%d",&num1,&num2); // 15  12

    printf("num1 > num2 = %d\n",num1 > num2);
    // num1 > num2 = 1

    printf("num1 >= num2 = %d\n",num1 >= num2);

    printf("num1 < num2 = %d\n",num1 < num2);

    printf("num1 <= num2 = %d\n",num1 <= num2);

    printf("num1 == num2 = %d\n",num1 == num2);

    printf("num1 != num2 = %d\n",num1 != num2);


}