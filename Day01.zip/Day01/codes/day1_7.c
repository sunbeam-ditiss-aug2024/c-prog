// if-else
// check if the character is vowel or consonant.
// ASCII
#include<stdio.h>

int main()
{
    char ch;

    printf("Enter the character !");

    scanf("%c",&ch);  // A : 65

    if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' ||
    ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' ||
    ch == 'U')
    {
        printf("%c is a Vowel !\n",ch);
    }
    else
        printf("%c is a consonant !\n",ch);
   return 0;
}