// switch - case
// calculator

#include<stdio.h>
/*
int main()
{
    char op;
    printf("Enter the Operator(+ - * /) : ");
    scanf("%c",&op); // *
    int num1, num2;

    printf("Enter the values for num1 and num2 :");
    scanf("%d%d",&num1,&num2); // 10 11

    switch(op) // *
    {
        case '+' :
                printf("%d + %d = %d\n",num1,num2,num1 + num2);
                break; // jump statement
        case '-' :
                printf("%d - %d = %d\n",num1,num2,num1 - num2);
                break;
        case '*' :
                printf("%d * %d = %d\n",num1,num2,num1 * num2);
                break;
        case '/' :

                printf("%d / %d = %d\n",num1,num2,num1 / num2);
                break;
        default :
               printf("Invalid Operator !\n");
        
    }
    return 0;
}
*/

int main()
{
    int choice;
    printf("1.Addition\n2.Subtraction\n3.Multiplication\n4.Division :");

    printf("Enter Your choice : ");
    scanf("%d",&choice); 
    int num1, num2;

    printf("Enter the values for num1 and num2 :");
    scanf("%d%d",&num1,&num2); // 10 11

    switch(choice) // 2
    {
        case 3 :
                printf("%d * %d = %d\n",num1,num2,num1 * num2);
                break;
        case 1 :
                printf("%d + %d = %d\n",num1,num2,num1 + num2);
                break; // jump statement
        case 2 :
                printf("%d - %d = %d\n",num1,num2,num1 - num2);
                break;
        case 4 :
                printf("%d / %d = %d\n",num1,num2,num1 / num2);
                break;
        default :
               printf("Invalid Operator !\n");
        
    }
    return 0;
}