// Operators : Logical ops 
// && || !
/*
Logical ops return 0(false) or 1(true)
&& requires both the conditions to be true
if 1st condition for && is false, it will not check the 2nd condition


|| requires any 1 condition to be true
if 1st condition for || is true , it will not check the 2nd condition
and it will return true

*/

#include<stdio.h>

void main()
{
    int num1, num2 , num3;

    printf("Enter the values for num1, num2 and num3 :");
    scanf("%d%d%d",&num1,&num2,&num3); // 20 25 15

    int result = num1 > num2 && num1 > num3;
               //  0 && (not checked)
               // result = 0
    printf("num1 > num2 && num1 > num3 = %d\n",result);


    result = num1 > num2 || num1 > num3;
    printf("num1 > num2 || num1 > num3 = %d\n",result);

    // result = 1
    printf("!result = %d\n",!result);
    // ! result = !1(!true)
    // = 0


}