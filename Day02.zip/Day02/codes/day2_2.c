// Loops : for loop
// program to reverse a number

// 12345  ==>   54321
#include<stdio.h>

int main()
{
    int num1, reverse = 0;
    printf("Enter the number to reverse :");
    scanf("%d",&num1); // 123


    int original = num1; // back up of num1 in original variable 
    
    for( ;num1 > 0 ; num1 /= 10) // num1 = 0
    {
        int digit = num1 % 10; // digit = 1
        reverse = reverse * 10 + digit; // reverse = 321
    }

    printf("The reverse number of %d  is %d !",original,reverse);
    
    return 0;
}

/*
short hand operators :

num1 += 10; // num1 = num1 + 10;
num1 -= 50; // num1 = num1 - 50;
num2 /= 10; // num2 = num2 / 10;


*/

/*

 for( ;num1 != 0; ) // num1 = 0
    {
        int digit = num1 % 10; // digit = 1
        reverse = reverse * 10 + digit; // reverse = 321
        num1 /= 10;
    }

    for(;;)
    {
        loop block
    }
*/