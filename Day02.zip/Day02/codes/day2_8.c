// jump statements : goto

#include<stdio.h>

int main()
{
    int i, j;

    for(i = 0; i<3; i++) // 0 1 2
    {
        for(j=0; j<4; j++) // 0 1 2 3
        {
            printf("%d  %d\n",i,j);
            if(j == 2)
                goto END;
        }
        printf("\n");
    }

    END :
        printf("Exited From the Loop !\n");
    return 0;
}