// functions : with parameters, without return type
// prime numbers within range

#include<stdio.h>

void print_prime_numbers(int start,int end) // 10 20
{
    int num,i,is_prime;

    for(num = start; num <= end; num++) // num = 13
    {
        if(num > 1)
        {
            is_prime = 1; // it is prime number
            for(i=2; i<=num/2 ; i++)
            {
                if(num % i == 0)
                {
                    is_prime = 0;
                    break;
                }
            }
            if(is_prime)// if(1)
                printf("%4d",num); // 11
            
        }
    }
}

int main()
{
    int start,end;

    printf("Enter the start of the range :");
    scanf("%d",&start); // 10

    printf("Enter the End of the range :");
    scanf("%d",&end); // 40

    printf("The Prime numbers between the range %d and %d are :\n",start,end);
    print_prime_numbers(start,end);

    return 0;
}
