// functions : with parameters, with return type
// addition

/*
Fun()
{
-----
---
--
---
}

return_type  function_name(input parameters)
return_type : the type of value that We want to return from
the function

function name : identifier / name given to the block of code

input parameters : input values that are used in the 
function block

*/

#include<stdio.h>

int addition(int n1,int n2,int n3); // function declaration
int main()
{
    int num1,num2,num3;

    printf("Enter the values for num1,num2 and num3 :");
    scanf("%d%d%d",&num1,&num2,&num3); // 23 10, 5
    int ans = addition(num1,num2,num3); // function call
            // actual parameters
    // int ans = 38
    printf("Answer = %d\n",ans);
    return 0;
}

// function definition
//           (formal parameters)
int addition(int n1,int n2,int n3)// 23 10  5
{
    int result = n1 + n2 + n3; // result = 38
    return result;   // return 38
}