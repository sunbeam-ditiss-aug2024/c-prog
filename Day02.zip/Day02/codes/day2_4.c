// do while loop : exit controlled loop
// the loop is executed atleast once, as the condition is checked at the exit.

#include<stdio.h>

int main()
{
    int num = 3;

    do
    {
        printf("num = %d\n",num); //3
        num++; // num = num + 1 => 4
    }while(num >= 5); // false
}



