// jump statements :
//break : used in switch case and in loops

#include<stdio.h>

int main()
{
    int count = 0;

    while(1) // infinte Loop
    {
        printf("%4d",count); // 0 2 4 6 8
        count = count+2; // 10
        if(count % 10 == 0)
        {
            printf("\n Count is %d, Breaking the loop !\n",count);
            break;
        }
        
    }


    
    return 0;
}


