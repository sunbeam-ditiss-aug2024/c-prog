// do while with switch case
#include<stdio.h>
#include<stdlib.h>
int main()
{
    int choice;
    int num1, num2;
    printf("Enter the values for num1 and num2 :");
    scanf("%d%d",&num1,&num2); // 10 11
do
{
    printf("1.Addition\n2.Subtraction\n3.Multiplication\n4.Division :");

    printf("\nEnter Your choice : ");
    scanf("%d",&choice); 
    

    switch(choice) // 2
    {
        case 0 : exit(0); // exit from the program 
        case 3 :
                printf("%d * %d = %d\n",num1,num2,num1 * num2);
                break;
        case 1 :
                printf("%d + %d = %d\n",num1,num2,num1 + num2);
                break; // jump statement
        case 2 :
                printf("%d - %d = %d\n",num1,num2,num1 - num2);
                break;
        case 4 :
                printf("%d / %d = %d\n",num1,num2,num1 / num2);
                break;
        default :
               printf("Invalid Operator !\n");
        
    }
}while(choice != 0);
    return 0;
}