// for loop
// Print a table
/*
loop variable initialization
condition check
loop variable modification
*/

#include<stdio.h>

int main()
{
    int num;
    int i;
    printf("Enter the number to print its table :");
    scanf("%d",&num);

    for(i = 1; i<=10; i++)
    {
        printf("%d * %d = %d\n",num,i,num * i);
    }
    return 0;
}