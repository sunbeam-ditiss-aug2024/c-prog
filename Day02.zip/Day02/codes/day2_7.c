// jump statements : continue
// continue is used only in loops

#include<stdio.h>

int main()
{
    for(int i =1; i<=10; i++)
    {
        if(i % 2 == 0)
            continue;

        printf("%d\n",i); // 1 3
    }
    return 0;
}