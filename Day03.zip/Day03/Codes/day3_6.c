// size of variables and size of a pointer variable

#include<stdio.h>

int main()
{
    int num1 = 10;
    printf("size of num1 = %d\n",sizeof(num1)); // 4
    int *ptr = &num1;
    printf("size of ptr = %d\n",sizeof(ptr));


    char ch = 'z';
    printf("size of ch = %d\n",sizeof(ch)); // 1
    char *c_ptr = &ch;
    printf("size of c_ptr = %d\n",sizeof(c_ptr));

    float fnum = 2.5;
    printf("size of fnum = %d\n",sizeof(fnum)); // 4
    float *f_ptr = &fnum;
    printf("size of f_ptr = %d\n",sizeof(f_ptr));


    double dnum = 5.6;
    printf("size of dnum = %d\n",sizeof(dnum)); // 8
    printf("size of int = %d\n",sizeof(int)); // 4
    double *d_ptr = &dnum;
    printf("size of d_ptr = %d\n",sizeof(d_ptr));
    
    return 0;
}