// pointers
// changing state of variable using pointer variable

#include<stdio.h>

int main()
{
    int num = 10;
    int *ptr = &num; // referencing

    // ptr is an integer pointer variable holding the address
    // of num

    printf("num = %d\n",num); // 10
    printf("Address of num = %u\n",&num); // 500(as per diagram)

    printf("ptr = %u\n",ptr); // value of ptr = 500(as per diagram)
    printf("Address of ptr = %u\n",&ptr); // 700(as per diagram)
   
   
    *ptr = 25;  // dereferencing (value at op)
    // value at ptr = 25

    printf("\n");
    printf("num = %d\n",num); // 25
    printf("Address of num = %u\n",&num); // 500
    printf("ptr = %u\n",ptr); // 500
    printf("Address of ptr = %u\n",&ptr); // 700
    printf("*ptr = %d\n",*ptr); // 25
    return 0; 
}