// storage classes :
// global

#include<stdio.h>

int num1; // global variable
void fun();
int main()
{
    int num1 = 10; // local variable
    printf("num1 in main() = %d\n",num1); // 10
    fun();
    fun(); 
    return 0;
}

void fun()
{
    printf("num1 in fun() = %d\n",num1); // 0
    num1 = 25;
}

/*
global variable :

default value : 0
scope : program
life : program
storage : data section

*/