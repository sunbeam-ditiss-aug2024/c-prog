// arrays declaration, printing
/*
arrays is a collection of similar data elements stored
in the contiguous/ continuous memory locations,
one after another.
*/
#include<stdio.h>

int main()
{
    int arr[5] = {11,12,13,14,15};

    printf("arr[3] = %d\n",arr[3]); // 14
    printf("arr[1] = %d\n",arr[1]); // 12
    printf("size of single element of an array = %d\n",sizeof(arr[4])); // 4
    printf("size of entire array = %d\n",sizeof(arr)); // 20
    
    // printing array elements :

    for(int i = 0; i< 5; i++)
    {
        printf("%4d",arr[i]);
    }

    int arr2[5];
    printf("\n Enter 5 values for the array :");

    for(int i =0;i<5;i++)
    {
        scanf("%d",&arr2[i]);
    }

    printf("The array elements are :");

    for(int i=0;i<5;i++)
    {
        printf("%4d",arr2[i]);
    }
    return 0;
}