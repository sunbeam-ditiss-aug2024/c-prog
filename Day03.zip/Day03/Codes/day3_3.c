// storage classes 
// static

#include<stdio.h>
void fun();
int main()
{
    int num1 = 10; // local varibale
    printf("num1 in main() = %d\n",num1); // 10
    
    fun();
    fun();
    fun();
    return 0;
}

void fun()
{
   static int num1;
    printf("num1 in fun() = %d\n",num1); // 0 2 4
    num1 = num1 + 2;
}



/*
static variable :

default value : 0
life : program
scope : limited 
storage : Data section


*/