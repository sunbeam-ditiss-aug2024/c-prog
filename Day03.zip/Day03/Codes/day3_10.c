// arrays in function

#include<stdio.h>
void accept_data(int arr[5]);
void print_data(int arr[5]);
int main()
{
    int arr[5]; // 20 bytes
    accept_data(arr);
    print_data(arr);
    printf("Size of arr in main() = %d\n",sizeof(arr));
    return 0;
}

void accept_data(int arr[5]) // 4 bytes
{
    printf("Enter the values for the array :");

    for(int i =0;i<5; i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("Size of arr in accept_Data() = %d\n",sizeof(arr));
}

void print_data(int arr[5])
{
    printf("\n The array elements are :\n");

    for(int i =0;i<5;i++)
    {
        printf("%4d",arr[i]);
    }
    printf("\n Size of arr in print_Data() = %d\n",sizeof(arr));
}