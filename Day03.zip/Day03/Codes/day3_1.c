// Storage classes :
// auto/ local variable
// register

#include<stdio.h>

int main()
{
    int num1; // local variable
    register int num2;
    printf("num1 = %d\n",num1);
    return 0;
}

void fun()
{
   // printf("num1 = %d\n",num1);
}

/*
local/auto variable :

scope / accessibility : block level
default value : garbage 
Life : block level
storage : stack section
_________________________________________
register variable :

scope / accessibility : block level
default value : garbage 
Life : block level
storage : CPU register(if request accepted)/ otherwise
            it is stored on the stack section

*/