// array of structure

#include<stdio.h>

struct employee
{
    int emp_id;
    char name[20];
    float salary;
};

int main()
{
    struct employee emp[3];

    printf("Enter the employee Info :\n");

    for(int i=0; i<3; i++)
    {
        printf("Emp Id = ");
        scanf("%d",&emp[i].emp_id);
        printf("Name :");
        scanf("%s",&emp[i].name);
        printf("Salary :");
        scanf("%f",&emp[i].salary);
    }

    printf("The Employee Info is :\n");

    for(int i=0; i<3; i++)
    {
        printf("\n Employee Details : %d\n",i +1);
        printf("Emp id = %d\n",emp[i].emp_id);
        printf("Name = %s\n",emp[i].name);
        printf("Salary = %.2f\n",emp[i].salary);
    }
    return 0;
}