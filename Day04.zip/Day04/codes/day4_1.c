// char arrays

#include<stdio.h>

int main()
{
    char str1[5] = {'A','B','C','D','E'};// char array

    char str2[5] = {'I','N','F','O'}; // string
    // partial initialization

    char str3[5] = {'P','U','N','E','\0'}; // string

    char str4[5] = "Tech"; // string

    char str5[4] = "Pune"; // char array

    char str6[] = "Sunbeam Info"; // string

    printf("str6 = %s\n",str6);
  //  printf("str5 = %s\n",str5);

  for(int i =0; i<4; i++)
  {
        printf("%c",str5[i]);
  }

    return 0;
}