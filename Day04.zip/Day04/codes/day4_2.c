// string functions

#include<stdio.h>
#include<string.h>

int main()
{
    char str1[] = "sunbeam Info";

    printf("string length = %d\n",strlen(str1)); // 12
    printf("string size = %d\n",sizeof(str1)); // 13

    char src[] = "Sunbeam";
    char dest[30];

    strcpy(dest,src);
    printf("src = %s  dest = %s\n",src,dest);

    char str2[] = "Sunbeam Info";

    int result = strcmp(str1,str2); // 0,1,-1

    if(result == 0)
        printf("The strings are Equal !\n");
    else if(result > 0)
        printf("String 1 is Greater !\n");
    else
        printf("String 2 is Greater !\n");

    char src1[] = " Pune";
    char dest1[] = "Sunbeam ";

    strcat(dest1,src1);
    printf("dest1 = %s\n",dest1);

    char ch = 'b';
    char *ptr = strchr(str1,ch);
    printf("char ch is found at index = %d\n",ptr-str1);

    char sub_str[] = "Info";
     char *ptr1 = strstr(str1,sub_str);
     printf("sub string found at index = %d\n",ptr1 - str1);
    return 0;
}