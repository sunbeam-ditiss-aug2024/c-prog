// calloc and realloc

#include<stdio.h>
#include<stdlib.h>

int main()
{
    int *ptr =(int *) calloc(sizeof(int),3);

    printf("enter 3 values :");

    for(int i=0; i<3; i++)
    {
        scanf("%d",&ptr[i]); // 10 20 30
    }

    printf("The Elements are :");
    for(int i =0; i<3; i++)
    {
        printf("%4d",ptr[i]);
    }

     ptr =(int *) realloc(ptr,sizeof(int) * 6);

     ptr[3] = 40;
     ptr[4] = 55;
     ptr[5] = 75;

    printf("\n Realloc :\n");
     for(int i=0; i<6; i++)
     {
        printf("%4d",ptr[i]);
     }

     free(ptr);
     ptr = NULL;
    return 0;
}