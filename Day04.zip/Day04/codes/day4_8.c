// passing structure to the function

#include<stdio.h>
struct date
{
    int dd;
    int mm;
    int yy;
};
// void accept_data(struct date d1);
void accept_Data(struct date *ptr);
void print_data(struct date d1);
int main()
{

    struct date d1;
  //  accept_data(d1); // pass by value
    accept_Data(&d1);
    print_data(d1);
    return 0;
}

// pass by value

/*
void accept_data(struct date d1)
{
    printf("Enter the date :");
    scanf("%d%d%d",&d1.dd,&d1.mm,&d1.yy);
}
*/

// pass by address
void accept_Data(struct date *ptr)
{
    printf("Enter the date in dd mm yyyy :");
    scanf("%d%d%d",&ptr->dd,&ptr->mm,&ptr->yy);
}

void print_data(struct date d1)
{
    printf("Date : %d-%d-%d\n",d1.dd,d1.mm,d1.yy);
}