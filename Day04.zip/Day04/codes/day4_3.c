// 2-D arrays

#include<stdio.h>
void accept_Data(int arr2[3][3]);
void print_data(int arr2[3][3]);
int main()
{
    int arr[3][2] = {11,22,33,44,55,66};
    int arr2[3][3];
    // rows
    // for(int i =0; i<3; i++)
    // {
    //     // columns
    //     for(int j=0; j<2; j++)
    //     {
    //         printf("%4d",arr[i][j]);
    //     }
    //     printf("\n");
    // }
    accept_Data(arr2);
    print_data(arr2);
    return 0;
}

void accept_Data(int arr2[3][3])
{
    printf("Enter the Array Elements :");

    for(int i=0; i<3; i++)
    {
        for(int j=0; j<3; j++)
        {
            printf("arr[%d][%d] :",i,j);
            scanf("%d",&arr2[i][j]);
        }
    }
}

void print_data(int arr2[3][3])
{
    printf("The array elements are :\n");

    for(int i =0; i<3; i++)
    {
        for(int j=0; j<3; j++)
        {
            printf("%4d",arr2[i][j]);
        }
        printf("\n");
    }
}