// dynamic memory allocation
// malloc

#include<stdio.h>
#include<stdlib.h>

int main()
{
    int num = 10; // compile time 

     int *ptr = (int *)malloc(sizeof(int));
     *ptr = 25;

     printf("*ptr = %d\n",*ptr);

     free(ptr); // to avoid memory leakage
     ptr = NULL; // to avoid dangling pointer
    return 0;
}