// structure : declaration, scanning and printing
// user-defined Data type

#include<stdio.h>

struct student
{
    int reg_id;
    char name[50];
    float marks;
};

int main()
{
    struct student s1 = {12345,"Nisha",90};

    printf("Reg id = %d\n",s1.reg_id);
    printf("Name = %s\n",s1.name);
    printf("Marks = %.2f\n",s1.marks);  

    struct student s2;
    printf("Enter the reg id :");
    scanf("%d",&s2.reg_id);

    printf("Enter the Name :");
    scanf("%s",&s2.name);

    printf("enter the marks :");
    scanf("%f",&s2.marks);

    printf("Reg id = %d  Name = %s  Marks = %.2f\n",s2.reg_id,s2.name,s2.marks);
    return 0;
}