// using 1 structure into another

#include<stdio.h>

struct date
{
    int dd;
    int mm;
    int yy;
};

struct employee
{
    int emp_id;
    char name[20];
    int salary;
    struct date DOB;
    struct date DOJ;
};

int main()
{
    struct employee e1;

    printf("Enter the emp id name and salary :");
    scanf("%d%s%d",&e1.emp_id,&e1.name,&e1.salary);

    printf("Enter the employee Date of Birth :");
    scanf("%d%d%d",&e1.DOB.dd,&e1.DOB.mm,&e1.DOB.yy);

    printf("Enter the Employee Joining Date :");
    scanf("%d%d%d",&e1.DOJ.dd,&e1.DOJ.mm,&e1.DOJ.yy);

    printf("The Employee Details are :\n");
    printf("empid = %d\n",e1.emp_id);
    printf("Name = %s\n",e1.name);
    printf("Salary = %d\n",e1.salary);

    printf("Date of Birth = %d-%d-%d\n",e1.DOB.dd,e1.DOB.mm,e1.DOB.yy);
    printf("Date of Joining = %d-%d-%d\n",e1.DOJ.dd,e1.DOJ.mm,e1.DOJ.yy);

    return 0;
}